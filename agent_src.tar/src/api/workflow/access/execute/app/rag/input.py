#!/usr/bin/env python
# -*- coding: utf-8 -*-


class Input:
    def __init__(self):
        pass

    def set_input(self, query: str) -> str:
        return query