#!/usr/bin/env python
# -*- coding: utf-8 -*-

from ailand.common.logger import Logger

logger = Logger().getLogger()
logger.debug("TEST")