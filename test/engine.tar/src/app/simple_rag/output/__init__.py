#!/usr/bin/env python
# -*- coding: utf-8 -*-

__all__ = ['prompt_template','rag_output']