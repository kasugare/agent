#!/usr/bin/env python
# -*- coding: utf-8 -*-

class Service:
    def __init__(self, logger, db_conn):
        self._logger = logger