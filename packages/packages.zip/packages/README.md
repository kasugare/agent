A brief description of what this package does.

## Installation

You can install the package via pip:

```
pip install ailand
```

## Usage

```python
from ailand.common.logger import Logger

result = Logger()
print(result)
```